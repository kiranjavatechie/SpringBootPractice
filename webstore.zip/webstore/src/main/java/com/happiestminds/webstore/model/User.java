
package com.happiestminds.webstore.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

/*
 * Revision History
 * --------------------------------------------------------------------------------------------------------------
 * Author			Description												          Version			Date
 * --------------------------------------------------------------------------------------------------------------
 * Lekhya	      User Class for storing User details of the web store who register	   1.0				07-MAR-2021
 */

@Getter
@NoArgsConstructor
@Data
@Entity
@Table(name = "user")
public class User  implements Serializable {
	
	  @Id
	  @GeneratedValue(strategy = GenerationType.IDENTITY)
	  private Long id;

    @NotEmpty(message = "UserName can not be empty")
    private String userName;

    @NotEmpty(message = "Email can not be empty")
    @Email(message = "Please provide a valid email id")
    private String email;

    @NotEmpty(message = "Password can not be empty")
    private String password;

}
