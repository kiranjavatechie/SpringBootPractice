package com.happiestminds.webstore.dao;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.happiestminds.webstore.model.User;

import java.util.Optional;
/*
 * Revision History
 * --------------------------------------------------------------------------------------------------------------
 * Author			Description												          Version			Date
 * --------------------------------------------------------------------------------------------------------------
 * Lekhya	      User Repository which implements JPA Repository for 
 *                 Persistence Operations like Save find and others              	   1.0				07-MAR-2021
 */


@Repository
public interface UserRepository extends JpaRepository<User, Long> {
	
	
	 Optional<User> findByUserName(String userName);

	 Optional<User> findByEmail(String email);

	 Optional<User> findById(String id);

    
}
