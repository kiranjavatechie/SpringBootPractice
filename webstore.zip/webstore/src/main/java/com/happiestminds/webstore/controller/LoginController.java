package com.happiestminds.webstore.controller;

import java.util.Optional;

import javax.validation.Valid;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.happiestminds.webstore.dao.UserRepository;
import com.happiestminds.webstore.model.LoginRequest;
import com.happiestminds.webstore.model.User;
import com.happiestminds.webstore.util.ApiResponse;
import com.happiestminds.webstore.util.EncryptService;




/*
 * Revision History
 * --------------------------------------------------------------------------------------------------------------
 * Author			Description												          Version			Date
 * --------------------------------------------------------------------------------------------------------------
 * Lekhya	        Login the users by using this class               	                1.0				07-MAR-2021
 */
/*
* ------------------------------------------------------------------------------------------------------
* REST EndPoint				HTTP Method		              Description
* ------------------------------------------------------------------------------------------------------
* /loginUser	                 POST			        Verify and get User Information while login 
*  
*/
@CrossOrigin
@RestController
@RequestMapping("/api/login")
public class LoginController {

	private static final Log log = LogFactory.getLog(LoginController.class);

	@Autowired
	UserRepository userRepository;

	@Autowired
	EncryptService encryptService;
	


	
	

/**
 * This method verifies the User and login into the application 
 * @param userData
 * @return
 */
	@PostMapping("/loginUser")
	public ResponseEntity loginUser(@Valid @RequestBody LoginRequest userData) {
	
	
		Optional<User> optional = userRepository.findByEmail(userData.getEmail());

		if (optional.isPresent() && encryptService.check(userData.getPassword(), optional.get().getPassword())) {
			User userRes = userRepository.findById(optional.get().getId()).get();
			log.info("User Successfully Logged In------>");
			return ResponseEntity.ok(userRes);
		} else {
			log.info("Invalid Email or Password  ");
			
			return new ResponseEntity(new ApiResponse(false, "Invalid Email or Password"), HttpStatus.BAD_REQUEST);
		}
		
	}

	
}
