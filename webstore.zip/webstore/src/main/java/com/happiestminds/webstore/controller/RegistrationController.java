package com.happiestminds.webstore.controller;

import java.util.Optional;

import javax.validation.Valid;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.happiestminds.webstore.dao.UserRepository;
import com.happiestminds.webstore.model.User;
import com.happiestminds.webstore.util.ApiResponse;
import com.happiestminds.webstore.util.EncryptService;

/*
 * Revision History
 * --------------------------------------------------------------------------------------------------------------
 * Author			Description												          Version			Date
 * --------------------------------------------------------------------------------------------------------------
 * Lekhya	        Registering  the users by using this class               	       1.0				07-MAR-2021
 */
/*
* ------------------------------------------------------------------------------------------------------
* REST EndPoint				HTTP Method		       Description
* ------------------------------------------------------------------------------------------------------
* /addUser	                 POST			         Added User Information while register 
*  
*/
@CrossOrigin
@RestController
@RequestMapping("/api/register")
public class RegistrationController {

	private static final Log log = LogFactory.getLog(RegistrationController.class);
	
	@Autowired
	UserRepository userRepository;

	@Autowired
	EncryptService encryptService;

	
	
/**
 * This method add user details into Database 
 * @param userdetails
 * @return user response with message
 */
	@SuppressWarnings("rawtypes")
	@PostMapping("/addUser")
	public ResponseEntity addUser(@Valid @RequestBody User userdetails) {
               log.info("Add User Details method starts ------>");
		Optional<User> optional = userRepository.findByEmail(userdetails.getEmail());
		if (optional.isPresent()) {
			log.info("Given Email already exists  ");
			return new ResponseEntity(new ApiResponse(false, "Email Address already in use!"), HttpStatus.BAD_REQUEST);
		} else {
			User userData = new User();
			userData.setEmail(userdetails.getEmail());
			userData.setUserName(userdetails.getUserName());
			userData.setPassword(encryptService.encrypt(userdetails.getPassword()));

			userRepository.save(userData);
			User userResponse = userRepository.findByUserName(userData.getUserName()).get();
			log.info("User Response after sucessfully register"+userResponse);
			log.info("Add User Details method ends ------>");
			return new ResponseEntity(new ApiResponse(true, "User registered successfully"), HttpStatus.CREATED);
			
		}
		
	}
	
	

}
